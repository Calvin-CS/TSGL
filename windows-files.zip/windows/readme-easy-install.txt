To set up TSGL for Windows
  Prerequisites
    Visual Studio 11.0 (2012)
    Visual Studio 10.0 (2010) [potentially]
  Setup
    Run tsgl-setup.exe
    Point the installer to the TSGL root directory (i.e., where the makefile is)
    Run the installer; it should create an include/ and lib/ folder in the TSGL root directory
    Copy the files in "tsgl-win" to your TSGL root directory
    Open tsgl.sln in VS 11.0 (2012)
    Right click on solution -> Build Solution
    Done! Right click on any of the test projects -> Debug -> Start New Instance to get started!
